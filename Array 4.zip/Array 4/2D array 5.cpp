// 2D array

#include<iostream>
#include<conio.h>

using namespace std;
int main()
{
    int row,colm, A[2][3] = { {10,20,30}, {20,30,10}};



    for(row=0; row<2; row++)
    {
        for(colm=0; colm<3; colm++)
        {
            cout<<A[row][colm] << " ";
        }
        cout<<endl;
    }




    getch();
}
