// Getting input for 2D Array;
#include<iostream>
#include<conio.h>

using namespace std;
int main()
{
    int row,colm,A[2][3];



     cout<<"Enter the elements for matrix : "<<endl;
     for(row=0; row<2; row++)
    {

        for(colm=0; colm<3; colm++)
        {
            cout<<"A[" <<row<<"]["<<colm<< " = ";
            cin >> A[row][colm] ;
        }
        cout<<endl;
    }

    cout<<"The matrix : " <<endl;
     for(row=0; row<2; row++)
    {
        for(colm=0; colm<3; colm++)
        {
            cout<< A[row][colm]<<" " ;
        }
        cout<<endl;
    }

    getch();
}
