// Use of array

#include<iostream>
#include<conio.h>

using namespace std;
int main()
{
   int marks[]={10,20,30,40,50};

   cout<<" "<<marks[0];
   cout<<" "<<marks[1];
   cout<<" "<<marks[2];
   cout<<" "<<marks[3];
   cout<<" "<<marks[4];
    getch();
}

