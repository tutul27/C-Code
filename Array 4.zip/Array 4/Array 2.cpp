// Use of array

#include<iostream>
#include<conio.h>

using namespace std;
int main()
{
   int i, marks[]={10,20,30,40,50};

   for(i=0; i<5; i++)
    cout<<marks[i]<<endl;
    getch();
}


