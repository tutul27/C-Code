// Getting input in array;

#include<iostream>
#include<conio.h>

using namespace std;
int main()
{
    int i,marks[5];

    cout<<"Enter 5 marks :"<<endl;
    for(i=0; i<5; i++)
    {
        cout<<"Marks for student : " <<i+1 <<" = ";
        cin>>marks[i];
    }

    for(i=0; i<5; i++)
    {
        cout<<marks[i]<<endl;
    }



    getch();
}
