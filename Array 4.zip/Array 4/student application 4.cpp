// Student Application;

#include<iostream>
#include<conio.h>

using namespace std;
int main()
{
    int n,i,sum=0;

    cout<<"Number of students : ";
    cin>>n;

    //input
    int students[n];
    for(i=0; i<n; i++)
    {
       cout<<"Marks for student : " <<i+1 <<" = ";
        cin>>students[i];
        sum = sum + students[i];
    }
    cout<<endl;
    cout<<"Total marks : "<<sum<<endl;
    float avg = (float) sum/n;
    cout<<"Average : " <<avg<<endl;

    //maximum and minimum;
    int max = students[0];
    int min = students[0];
    for(i=1; i<n; i++)
    {
        if(max < students[i])
        {
            max = students[i];
        }
        if(min > students[i])
        {
            min = students[i];
        }

    }

    cout << "Maximum marks = " << max<<endl;
    cout << "Minimum marks = " << max;



    getch();
}
