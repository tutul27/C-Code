// Use of Default constructor;

#include<iostream>
#include<conio.h>
using namespace std;

class students
{
public:
    int id;
    double cgpa;

    void display()
    {

      cout<<"Id = "<<id<< endl;
      cout<<"Cgpa "<<cgpa<<endl;

    }

    // Constructor declare
    students(int x, double y) //Parametrized constructor
    {
        id = x;
        cgpa = y;
    }
    students() // default constructor
    {
        cout<<"Default Constructor : "<<endl;

        int i, sum = 0;
        for(i=0; i<5; i++)
        {
            cout<<i<<" ";

        }
         cout<<"Default constructor finish : "<<endl;

    }

};

int main()
{

     students op;
     cout<<endl;

      cout<<"Tutul Information  : "<<endl;
      //tutul.setvalue(160129,2.84);
      students tutul(160129,2.84);
      tutul.display();
      cout<<endl;


      cout<<"Pias Information : "<<endl;
      students pias(160146,2.95);
      pias.display();
      cout<<endl;

      cout<<"Mostak Information : "<<endl;
      students Mostak(160134,3.34);
      Mostak.display();
      cout<<endl;


      // Constructor is a special type of function that is used to initialize the object;
      // Properties of Constructor
      // 1. special type of function
      // 2. Constructor has the same name as that of the class it belongs
      // 3. it has no return type not even void
      // 4. it is called automatically.



    getch();
}



