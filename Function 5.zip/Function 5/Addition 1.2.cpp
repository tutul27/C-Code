// Create an addition function;

#include<iostream>
#include<conio.h>

using namespace std;

void addition(int a, int b)
{
    int sum,sub;
    sum = a+b;
    cout<<"Addition = " << sum <<endl;

}
int main()
{

    cout<<"Enter 5 times " <<endl;
    for(int i=0; i<5; i++)
         {
              int x,y;
     cout << "Enter x = ";
     cin>>x;
     cout<<"Enter y = ";
     cin>>y;

    //calling function;
    addition(x,y);
    cout<<endl;
    //addition(20,30);
         }
     cout <<"Finis";

    getch();
}

