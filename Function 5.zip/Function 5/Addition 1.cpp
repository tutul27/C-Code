// Create an addition function;

#include<iostream>
#include<conio.h>

using namespace std;

void addition(int a, int b)
{
    int sum,sub;
    sum = a+b;
    cout<<"Addition = " << sum <<endl;

}
int main()
{


    //calling function;
    addition(10,20);
    addition(20,30);


    getch();
}
