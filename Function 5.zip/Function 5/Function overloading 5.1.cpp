// Function overloading

#include<iostream>
#include<conio.h>
using namespace std;

void sum(int a)
{

    cout<<"a = "<<a<<endl;
}

void sum(double a)// different parameter
{
     ;
    cout<<"a = "<<a;
}
int main()
{

    //calling function;
    sum(10);
    sum(10.4);

    getch();
}

