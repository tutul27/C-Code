// Function overloading

#include<iostream>
#include<conio.h>
using namespace std;

void sum(int a, int b)
{
    int sum = a + b;
    cout<<"Sum = "<<sum<<endl;
}

void sum(int a, int b, int c)
{
    int sum = a + b + c;
    cout<<"Sum = "<<sum;
}
int main()
{

    int x, y, z;

    cout<<"Enter x = ";
    cin>>x;

    cout<<"Enter x = ";
    cin>>y;

    cout<<"Enter x = ";
    cin>>z;

     cout<<endl;
    //calling function;
    sum(x,y);
    sum(x,y,z);

    getch();
}

