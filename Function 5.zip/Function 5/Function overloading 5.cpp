// Function overloading

#include<iostream>
#include<conio.h>
using namespace std;

void sum(int a, int b)
{
    int sum = a + b;
    cout<<"Sum = "<<sum<<endl;
}

void sum(int a, int b, int c)
{
    int sum = a + b + c;
    cout<<"Sum = "<<sum;
}
int main()
{

    //calling function;
    sum(10,20);
    sum(10,20,30);

    getch();
}
