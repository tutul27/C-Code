// Create a multiplication function;

#include<iostream>
#include<conio.h>

using namespace std;

void addition(int a, int b)
{
    int sum,sub;
    sum = a+b;
    cout<<"Addition = " << sum <<endl;

}
void divition(int a, int b)
{
    int sum,sub;
    sum = (float)a/b;
    cout<<"Divition = " << sum <<endl;

}
void subtraction(int a, int b)
{
    int sum,sub;
    sum = a-b;
    cout<<"Subtraction = " << sum <<endl;
}
void multiplicatin(int a, int b)
{
    int sum,sub;
    sum = a*b;
    cout<<"Multiplicatin = " << sum <<endl;

}
int main()
{
    int x,y;
     cout << "Enter x = ";
     cin>>x;
     cout<<"Enter y = ";
     cin>>y;


     cout<<endl;
    //calling function;
    addition(x,y);
    divition(x,y);
    subtraction(x,y);
    multiplicatin(x,y);


    getch();
}


