// Create a multiplication function;

#include<iostream>
#include<conio.h>

using namespace std;

void addition(int a, int b)
{
    int sum,sub;
    sum = a+b;
    cout<<"Addition = " << sum <<endl;

}
void divition(int a, int b)
{
    int sum,sub;
    sum = (float)a/b;
    cout<<"Divition = " << sum <<endl;

}
void subtraction(int a, int b)
{
    int sum,sub;
    sum = a-b;
    cout<<"Subtraction = " << sum <<endl;
}
void multiplicatin(int a, int b)
{
    int sum,sub;
    sum = a*b;
    cout<<"Multiplicatin = " << sum <<endl;

}
int main()
{


    //calling function;
    addition(10,20);
    divition(30,20);
    subtraction(5,9);
    multiplicatin(4,6);


    getch();
}

