// Create an addition function;

#include<iostream>
#include<conio.h>

using namespace std;

int addition(int a, int b)
{
    int sum,sub;
    sum = a+b;
    return sum;

}
int main()
{

     int x,y;
     cout << "Enter x = ";
     cin>>x;
     cout<<"Enter y = ";
     cin>>y;



    //calling function;
    cout<<"Addition = "<<addition(x,y);


    getch();
}


