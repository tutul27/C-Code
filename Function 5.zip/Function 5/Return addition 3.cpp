// Create an addition function;

#include<iostream>
#include<conio.h>

using namespace std;

int addition(int a, int b)
{
    int sum,sub;
    sum = a+b;
    return sum;

}
int main()
{

    //calling function;
    cout<<"Addition = "<<addition(10,20);


    getch();
}

