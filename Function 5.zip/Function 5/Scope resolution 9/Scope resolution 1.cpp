// Scope Resolution

#include<iostream>
#include<conio.h>
using namespace std;


int main()
{
     int x =10; // local variable
    cout<<x<<endl;


    getch();
}
