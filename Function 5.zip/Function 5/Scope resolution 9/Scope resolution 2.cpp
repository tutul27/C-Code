// Scope Resolution

#include<iostream>
#include<conio.h>
using namespace std;

 int x = 20; // global variable
void display()
{
    cout<<x<<endl;
}

int main()
{
     int x =10; // local variable
    cout<<x<<endl;
    display();

    getch();
}

