// Scope Resolution
// Scope resolution operator indicates that print global variable;
#include<iostream>
#include<conio.h>
using namespace std;

int x = 20; // global variable


int main()
{
     int x =10; // local variable
     //:: x = 40;
    cout<< :: x<<endl;  //          :: scope resolution operator;


    getch();
}


