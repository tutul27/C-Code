// Passing Array to function

#include<iostream>
#include<conio.h>
using namespace std;

void DisplayArray(int num[])
{
    int i;
    for(i=0; i<5; i++)
        cout<<num[i] <<" "<<endl;
}

int main()
{
    int number[5] = {10,20,30,40,50};
    DisplayArray(number);


    getch();
}
