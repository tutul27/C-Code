// Create an addition function;

// default arguments;

#include<iostream>
#include<conio.h>

using namespace std;

int display(int a=10, int b=7)
{
    cout<<"a = "<<a<<endl;
    cout<<"b = "<<b<<endl;

}
int main()
{
    display();
    cout<<endl;
    display(26);

    getch();
}


