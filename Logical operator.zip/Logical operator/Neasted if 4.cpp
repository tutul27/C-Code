// Letter Grade program
// Use Nested if

#include<iostream>
#include<conio.h>

using namespace std;
int main()
{
    int marks;
    cout << "Enter your marks : ";
    cin >> marks;

    if(marks > 100)
    {
        cout << "Invalid number";
    }

    else if(marks < 0)
    {
        cout << "Invalid number";
    }


    else if(marks >= 33)
    {
        if(marks >= 80)
        {
            cout << "Your get A+";
        }
        else if(marks >= 70)
        {
            cout << "Your get A";
        }
         else if(marks >= 60)
        {
            cout << "Your get A-";
        }
         else if(marks >= 50)
        {
            cout << "Your get B";
        }
         else if(marks >= 40)
        {
            cout << "Your get C";
        }

    }

    else
        cout << "Fail";


    getch();
}
