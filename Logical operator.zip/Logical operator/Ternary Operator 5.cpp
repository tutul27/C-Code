// Use of ternary Operator

#include<iostream>
#include<conio.h>

using namespace std;
int main()
{
    int num;
    cout << "Enter your integer : ";
    cin >>num;
    // use of ternary operator
    (num%2==0) ? cout<<"Even" : cout<<"Odd";

    getch();
}
