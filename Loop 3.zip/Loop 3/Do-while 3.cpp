// Do-while-loop statement;

#include<iostream>
#include<conio.h>

using namespace std;
int main()
{
    int i = 0;
    int sum = 0;

    do
    {
        cout<<" "<<i<<endl;
        sum = sum + i;
        i++;
    }while(i<20);
    cout<<endl;
    cout<<"Sum of n Numbers " <<sum;

    getch();
}


