// Do-while-loop statement;

#include<iostream>
#include<conio.h>

using namespace std;
int main()
{
    int n,i = 0,sum = 0;
    cout<<"Enter any Integer number n = ";
    cin>>n;


    do{
        sum = sum + i;
        i++;
    }while(i<n);
    cout<<endl;
    cout<<"Sum of n Numbers = " <<sum;

    getch();
}



