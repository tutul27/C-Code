// loop statement;

#include<iostream>
#include<conio.h>

using namespace std;
int main()
{
    int i;
    int sum = 0;

    for(i=0; i<10; i= i+2)
    {

        sum = sum + i;

    }
    cout <<"Sum = " << sum;


    getch();
}
