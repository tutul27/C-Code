// While-loop statement;

#include<iostream>
#include<conio.h>

using namespace std;
int main()
{
    int i = 0;


    while(i<20)
    {
        cout<<" "<<i;
        i++;
    }

    getch();
}

