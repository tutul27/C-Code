// Constructor initializer

#include<iostream>
#include<conio.h>
using namespace std;

class students
{
public:
    const int admissionFee;
    const int examFee;

    students(int x, int y) //constructor declaration
    : admissionFee(x),examFee(y) // const declaration

    {

        cout<<"AdmissionFee = "<<admissionFee<<endl;
        cout<<"ExamFee = "<<examFee<<endl;
    }
};

int main()
{
     cout <<"Tutul cost : "<<endl;
     students tutul(15000,500);
     cout<<endl;
     students khaled(20000,600);

    getch();
}
