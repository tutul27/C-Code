// Encapsulation;
// Ned set and get method;

// Encapsulation use for data private and protected;

#include<iostream>
#include<conio.h>
using namespace std;

class student
{
    private:
        string name;
    public:
        void setName(string x)
        {
            name = x;
        }
        string getName()
        {
            return name;
        }
};

int main()
{
    student sl;
    sl.setName("Tutul");
    cout<<sl.getName();



}
