
//Use of THis keyword
#include<iostream>
#include<conio.h>
using namespace std;

class student
{
public :
    string name;

    student(string name)
    {
      this ->  name = name; // this keyword use for indicate class variable;
    }
    void display()
    {
        cout<< name<<endl;
    }

};

int main()
{
    student s1("Tutul");
    s1.display();

    getch();
}

