
//Use of THis keyword
#include<iostream>
#include<conio.h>
using namespace std;

class student
{
public :
    string name;

    student(string x)
    {
        name = x;
    }
    void display()
    {
        cout<< name<<endl;
    }

};

int main()
{
    student s1("Tutul");
    s1.display();

    getch();
}
