
// Use Of Inheritance

#include<iostream>
#include<conio.h>
using namespace std;

class Person
{
public:
    string name;
    int age;

    void display1()
    {
        cout<<"Name : "<<name<<endl;
        cout<<"Age : "<<age<<endl;
    }
};

class student : public Person
{
public:
    // name, age, display1()
    int id;

    void display2()
    {
        cout<<"ID : "<<id<<endl;
        //cout<<"Name : "<<name<<endl;
        //cout<<"Age : "<<age<<endl;
        display1();
    }


};

int main()
{
    student sl;
    sl.id = 160129;
    sl.name = "Md Tutul Haque";
    sl.age = 29;
    sl.display2();


    getch();
}
