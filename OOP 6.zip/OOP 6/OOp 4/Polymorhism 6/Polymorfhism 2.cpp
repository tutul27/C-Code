//
// Polymorphism
// we can pointer create superclass NOT sub class;

#include<iostream>
#include<conio.h>
using namespace std;


class Person
{
public:
    virtual void display()
    {
        cout<<"I am tutul.I am a Person. "<<endl;
    }
};

class student : public Person
{
public:
    void display()
    {
        cout<<"I am student "<<endl;
    }
};

class Teacher : public Person
{
public:
    void display()
    {
        cout<<"I am a Teacher "<<endl;
    }
};

int main()
{
    Teacher t;
    student s;
    Person *p;

    p = &s;


    p -> display();




    getch();
}


