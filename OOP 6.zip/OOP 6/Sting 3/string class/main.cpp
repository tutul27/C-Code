
// string class
#include <iostream>
#include<conio.h> // use for getch()
#include<cstring>
#include<string>

using namespace std;

int main()
{
    string str1 = "Md Tutul";
    string str2 = " Haque";
    string str3;

    str3 = str1;
    cout<<"Str3 = "<<str3<<endl;

    str3 = str1 + str2;
    cout<<"Str1 + Str2 = " <<str3<<endl;

    int len = str1.size();
    cout<<"Length of str1 = "<<len;




    getch();
}
