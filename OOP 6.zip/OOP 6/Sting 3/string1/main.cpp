#include <iostream>
#include<stdio.h>


using namespace std;

int main()
{
    char message[6] = {'t','u','t','u','l'};
    //char message[] = {'t','u','t','u','l','\0'};
     //char message[] = "Md Tutul Haque ";
    cout<<message<<endl;
    cout<<message[4]<<endl;

    char names[80];
    cout<<"Enter your name : ";
    gets(names);
    cout<<"Welcome " <<names;

  return 0;
}
