// Class and object;

#include<iostream>
#include<conio.h>
using namespace std;

//class declaration
// class class_name
class students
{
public:
    int id;
    double cgpa;
};

int main()
{
      //Object declaration
      //class_name object_Name
      students tutul, pias, Mostak;

      tutul.id = 160129;
      tutul.cgpa = 2.84;
      cout<<"Tutul Information : "<<endl;
      cout<<"Tutul id = "<<tutul.id <<endl;
      cout<<"Tutul cgpa = "<<tutul.cgpa<<endl;
      cout<<endl;


      pias.id = 160146;
      pias.cgpa = 2.95;
      cout<<"Pias Information : "<<endl;
      cout<<"Pias id = "<<pias.id <<endl;
      cout<<"Pias cgpa = "<<pias.cgpa<<endl;
      cout<<endl;

      Mostak.id = 160134;
      Mostak.cgpa = 3.34;
      cout<<"Mostak Information : "<<endl;
      cout<<"Mostak id = "<<Mostak.id <<endl;
      cout<<"Mostak cgpa = "<<Mostak.cgpa<<endl;


    getch();
}
