// Adding function to the class;

#include<iostream>
#include<conio.h>
using namespace std;

class students
{
public:
    int id;
    double cgpa;

    void display()
    {

      cout<<"Id = "<<id<< endl;
      cout<<"Cgpa "<<cgpa<<endl;

    }
};

int main()
{

      students tutul, pias;

      tutul.id = 160129;
      tutul.cgpa = 2.84;
      cout<<"Tutul Information  : "<<endl;
      tutul.display();
      cout<<endl;


      cout<<"Pias Information : "<<endl;
      pias.id = 160146;
      pias.cgpa = 2.95;
      pias.display();




    getch();
}

