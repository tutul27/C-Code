// Adding parametrized function to the class;

#include<iostream>
#include<conio.h>
using namespace std;

class students
{
public:
    int id;
    double cgpa;

    void display()
    {

      cout<<"Id = "<<id<< endl;
      cout<<"Cgpa "<<cgpa<<endl;

    }
    void setvalue(int x, double y)
    {
        id  = x;
        cgpa = y;
    }
};

int main()
{

      students tutul, pias;


      cout<<"Tutul Information  : "<<endl;
      tutul.setvalue(160129,2.84);
      tutul.display();
      cout<<endl;


      cout<<"Pias Information : "<<endl;
      pias.setvalue(160146,2.95);
      pias.display();




    getch();
}



