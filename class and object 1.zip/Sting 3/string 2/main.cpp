
// String library function
#include <iostream>
#include<conio.h> // use for getch()
#include<cstring>

using namespace std;

int main()
{


   char name1[] = "Md tutul haque. ";
   char name2[50];
   char name3[] = "I am a student of Just.";
   cout<<"Use of strlen() : "<<endl;
   int len = strlen(name1);
   cout<<"Lenght = "<<len <<endl;
   cout<<endl;

    cout<<"Use of strcpy() function : "<<endl;
    strcpy(name2,name1);
    cout<<"Names2 = "<<name2<<endl;
    cout<<endl;

    cout<<"Use of strcat() function : "<<endl;
    strcat(name1,name3);
    cout<<"Concat = "<<name1<<endl;
    cout<<endl;

    cout<<"Use of strupr() function : " <<endl;
    strupr(name3);
    cout<<name3<<endl;
    cout<<endl;

    cout<<"Use of strlwr() function : " <<endl;
    strlwr(name3);
    cout<<name3<<endl;
    cout<<endl;

    char nam1[] = "Tutul";
    char nam2[]= "tutul";
    cout<<"Use of strcmp() function : " <<endl;
    int value = strcmp(nam1,nam2);
    if(value == 0)
        cout<<"String is equal ";
    else
        cout<<"String is not equal ";



   getch();
}
